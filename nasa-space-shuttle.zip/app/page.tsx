'use client'

import { useState } from 'react'
import { ArrowDown, ArrowUpRight, ChevronRight, Radio, Rocket, Orbit, Menu, X } from 'lucide-react'

const missions = [
  { year: '1981', name: 'STS-1', label: 'First flight', copy: 'Columbia proves a spacecraft can launch like a rocket and land like a glider.' },
  { year: '1990', name: 'STS-31', label: 'Hubble deployed', copy: 'Discovery carries humanity’s eye into orbit, changing our view of the universe forever.' },
  { year: '1998', name: 'STS-88', label: 'Station assembled', copy: 'Endeavour delivers the first piece of what becomes the International Space Station.' },
  { year: '2011', name: 'STS-135', label: 'Final mission', copy: 'Atlantis closes the program with one last delivery—and an impossible legacy.' },
]

export default function Page() {
  const [activeMission, setActiveMission] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <main className="min-h-screen overflow-hidden bg-background text-foreground">
      <header className="fixed inset-x-0 top-0 z-50 flex items-center justify-between px-5 py-5 mix-blend-difference text-white md:px-10">
        <a href="#top" className="flex items-center gap-3" aria-label="Orbiter home">
          <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/50 font-mono text-xs">O</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.28em]">The Orbiter Archive</span>
        </a>
        <nav className="hidden items-center gap-8 font-mono text-[10px] uppercase tracking-[0.2em] md:flex">
          <a href="#why" className="transition-opacity hover:opacity-60">Why it mattered</a>
          <a href="#missions" className="transition-opacity hover:opacity-60">Missions</a>
          <a href="#legacy" className="transition-opacity hover:opacity-60">Legacy</a>
        </nav>
        <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        {menuOpen && <nav className="absolute right-5 top-16 flex flex-col gap-4 border border-white/20 bg-background p-5 font-mono text-xs uppercase tracking-widest text-foreground md:hidden"><a href="#why" onClick={() => setMenuOpen(false)}>Why it mattered</a><a href="#missions" onClick={() => setMenuOpen(false)}>Missions</a><a href="#legacy" onClick={() => setMenuOpen(false)}>Legacy</a></nav>}
      </header>

      <section id="top" className="relative flex min-h-[92vh] items-end overflow-hidden px-5 pb-14 pt-32 md:min-h-screen md:px-10 md:pb-20">
        <img src="/shuttle-hero.png" alt="Space Shuttle launching at dawn" className="absolute inset-0 h-full w-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/30 to-black/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20" />
        <div className="relative z-10 max-w-5xl">
          <p className="mb-6 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.35em] text-accent"><span className="h-px w-8 bg-accent" />A machine unlike any other</p>
          <h1 className="max-w-4xl text-balance font-sans text-[clamp(3.5rem,10vw,9.5rem)] font-semibold uppercase leading-[0.84] tracking-[-0.07em] text-white">The most<br /><span className="text-accent">ambitious</span><br />machine ever flown.</h1>
          <div className="mt-10 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <p className="max-w-md text-pretty text-sm leading-6 text-white/75">For 30 years, the Space Shuttle turned the impossible into a flight plan. It launched, lived in orbit, and came home—again and again.</p>
            <a href="#why" className="group flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.25em] text-white"><span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/50 transition-colors group-hover:bg-accent group-hover:text-accent-foreground"><ArrowDown size={16} /></span>Scroll to explore</a>
          </div>
        </div>
        <span className="absolute bottom-6 right-5 font-mono text-[9px] tracking-[0.2em] text-white/50 md:right-10">28°36′N / 80°36′W</span>
      </section>

      <section id="why" className="relative bg-background px-5 py-24 md:px-10 md:py-40">
        <div className="mx-auto grid max-w-7xl gap-16 md:grid-cols-[0.8fr_1.2fr] md:gap-24">
          <div><p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">01 / Why it mattered</p><h2 className="mt-5 max-w-sm text-balance text-4xl font-semibold uppercase leading-none tracking-[-0.05em] md:text-6xl">A spaceship with a schedule.</h2></div>
          <div><p className="max-w-2xl text-pretty text-xl leading-8 text-muted-foreground md:text-3xl md:leading-10">The Shuttle was not simply a rocket. It was a reusable spacecraft, a flying laboratory, a construction crane, and a delivery truck for the stars.</p><div className="mt-14 grid grid-cols-2 gap-x-6 gap-y-10 border-t border-border pt-8 md:grid-cols-4"><Stat value="135" label="missions" /><Stat value="355" label="people flown" /><Stat value="1,334" label="days in orbit" /><Stat value="3,000+" label="experiments" /></div></div>
        </div>
      </section>

      <section className="border-y border-border bg-card px-5 py-20 md:px-10 md:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 md:grid-cols-2 md:gap-24"><div className="relative overflow-hidden bg-primary"><div className="absolute inset-0 bg-[linear-gradient(120deg,transparent_35%,rgba(255,255,255,.13)_50%,transparent_65%)]" /><div className="flex aspect-square flex-col justify-between p-7 text-primary-foreground md:p-10"><div className="flex justify-between font-mono text-[9px] uppercase tracking-[0.2em]"><span>Vehicle overview</span><span>OV-104</span></div><div className="relative mx-auto flex h-64 w-32 items-center justify-center md:h-80 md:w-40"><div className="h-full w-16 rounded-[45%_45%_18%_18%] border-4 border-primary-foreground/80 bg-card/10 md:w-20" /><div className="absolute bottom-0 h-24 w-28 rounded-[50%] border-2 border-accent/80 md:w-36" /><div className="absolute top-8 h-2 w-20 bg-accent/80 md:w-24" /></div><div className="flex justify-between font-mono text-[9px] uppercase tracking-[0.2em] text-primary-foreground/60"><span>Orbiter / Atlantis</span><span>1985—2011</span></div></div></div><div><p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">Built for the unknown</p><h2 className="mt-5 text-4xl font-semibold uppercase leading-none tracking-[-0.05em] md:text-6xl">Every surface had a job.</h2><p className="mt-7 max-w-lg text-pretty leading-7 text-muted-foreground">From its black thermal-protection tiles to its three liquid-fueled engines, the orbiter was a stack of solutions to problems no one had solved before.</p><div className="mt-8 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.2em] text-foreground"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-accent-foreground"><Rocket size={15} /></span>Reusable by design</div></div></div>
      </section>

      <section id="missions" className="px-5 py-24 md:px-10 md:py-40"><div className="mx-auto max-w-7xl"><div className="mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">02 / Mission log</p><h2 className="mt-5 text-4xl font-semibold uppercase leading-none tracking-[-0.05em] md:text-6xl">A few impossible days.</h2></div><p className="max-w-xs text-sm leading-6 text-muted-foreground">Select a mission to trace the arc of an extraordinary era.</p></div><div className="grid border-t border-border md:grid-cols-[0.75fr_1.25fr]">{missions.map((mission, index) => <button key={mission.name} onClick={() => setActiveMission(index)} className={`group flex items-center justify-between border-b border-border py-5 text-left transition-colors md:px-5 ${activeMission === index ? 'bg-accent text-accent-foreground' : 'hover:bg-card'}`}><span className="font-mono text-xs">{mission.year}</span><span className="flex items-center gap-5 text-sm font-semibold uppercase tracking-wide">{mission.name}<ChevronRight size={16} className={`transition-transform ${activeMission === index ? 'translate-x-1' : 'opacity-0 group-hover:opacity-100'}`} /></span></button>)}<div className="flex min-h-72 flex-col justify-between border-b border-border p-7 md:border-l md:p-12"><div><span className="font-mono text-[10px] uppercase tracking-[0.25em] text-accent">{missions[activeMission].label}</span><h3 className="mt-5 text-5xl font-semibold uppercase tracking-[-0.06em] md:text-8xl">{missions[activeMission].name}</h3><p className="mt-6 max-w-md leading-7 text-muted-foreground">{missions[activeMission].copy}</p></div><div className="mt-10 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground"><Radio size={13} className="text-accent" /> Mission archive / live record</div></div></div></div></section>

      <section id="legacy" className="relative overflow-hidden bg-primary px-5 py-24 text-primary-foreground md:px-10 md:py-36"><div className="absolute right-[-3rem] top-[-4rem] font-sans text-[20rem] font-bold leading-none tracking-[-0.15em] text-primary-foreground/[0.04]">O</div><div className="relative mx-auto max-w-7xl"><div className="grid gap-14 md:grid-cols-[1fr_1.3fr] md:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">03 / The legacy</p><h2 className="mt-5 text-5xl font-semibold uppercase leading-[0.9] tracking-[-0.07em] md:text-8xl">It changed<br />what we<br /><span className="text-accent">expect</span> from<br />the sky.</h2></div><div><p className="max-w-xl text-pretty text-xl leading-8 text-primary-foreground/70 md:text-3xl md:leading-10">The Shuttle taught us that exploration is not a single leap. It is a practice—built, tested, repaired, and flown again.</p><a href="#top" className="mt-10 inline-flex items-center gap-3 border border-primary-foreground/30 px-5 py-4 font-mono text-[10px] uppercase tracking-[0.2em] transition-colors hover:bg-accent hover:text-accent-foreground">Return to launch <ArrowUpRight size={15} /></a></div></div><div className="mt-24 flex flex-wrap items-center justify-between gap-6 border-t border-primary-foreground/20 pt-6 font-mono text-[9px] uppercase tracking-[0.2em] text-primary-foreground/50"><span className="flex items-center gap-2"><Orbit size={14} /> The Orbiter Archive</span><span>Made for the curious</span><span>NASA / 1981—2011</span></div></div></section>
    </main>
  )
}

function Stat({ value, label }: { value: string; label: string }) { return <div><div className="font-sans text-3xl font-semibold tracking-[-0.06em] md:text-4xl">{value}</div><div className="mt-2 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div></div> }

